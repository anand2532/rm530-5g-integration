"""Scripts package for RM530 5G integration."""

__all__ = []

